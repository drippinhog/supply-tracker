import { useState } from 'react'
import { purchaseOrders, shipments, calendarEvents } from './data/dummyData.js'

// ── Styles (CSS-in-JS as a single object for portability) ────────────────────
const s = {
  app: { maxWidth: 900, margin: '0 auto', background: 'var(--bg-primary)', minHeight: '100vh', borderLeft: '0.5px solid var(--border)', borderRight: '0.5px solid var(--border)' },
  header: { padding: '16px 20px 0', borderBottom: '0.5px solid var(--border)' },
  headerTop: { display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 },
  logo: { width: 32, height: 32, background: '#1a3a2a', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  titleWrap: {},
  title: { fontSize: 16, fontWeight: 500, color: 'var(--text-primary)' },
  subtitle: { fontSize: 13, color: 'var(--text-secondary)', marginTop: 1 },
  tabs: { display: 'flex' },
  tab: (active) => ({ padding: '8px 18px', fontSize: 14, fontWeight: active ? 500 : 400, color: active ? 'var(--text-primary)' : 'var(--text-secondary)', cursor: 'pointer', borderBottom: active ? '2px solid var(--text-primary)' : '2px solid transparent', background: 'none', border: 'none', borderBottom: active ? '2px solid var(--text-primary)' : '2px solid transparent' }),
  panel: { padding: 20 },
}

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']
const MONTH_SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']

// ── Calendar Tab ─────────────────────────────────────────────────────────────
function CalendarTab() {
  const today = new Date()
  const [year, setYear] = useState(2025)
  const [month, setMonth] = useState(5) // June

  const nav = (dir) => {
    let m = month + dir, y = year
    if (m > 11) { m = 0; y++ }
    if (m < 0)  { m = 11; y-- }
    setMonth(m); setYear(y)
  }

  const first = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const prevDays = new Date(year, month, 0).getDate()

  let cells = []
  for (let i = first - 1; i >= 0; i--) cells.push({ d: prevDays - i, other: true, month: month - 1, year })
  for (let d = 1; d <= daysInMonth; d++) cells.push({ d, other: false, month, year })
  while (cells.length % 7 !== 0) { cells.push({ d: cells.length - daysInMonth - first + 1, other: true, month: month + 1, year }) }

  const eventTypeStyle = {
    reminder: { background: '#FEF3C7', color: '#92400E', border: '0.5px solid #FCD34D' },
    shipment:  { background: '#DBEAFE', color: '#1E40AF', border: '0.5px solid #93C5FD' },
    arrival:   { background: '#D1FAE5', color: '#065F46', border: '0.5px solid #6EE7B7' },
    border:    { background: '#EDE9FE', color: '#5B21B6', border: '0.5px solid #C4B5FD' },
  }

  return (
    <div style={s.panel}>
      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: 16 }}>
        <div style={{ fontSize: 18, fontWeight: 500 }}>{MONTHS[month]} {year}</div>
        <div style={{ display:'flex', gap: 8 }}>
          {['← Prev','Next →'].map((lbl, i) => (
            <button key={lbl} onClick={() => nav(i === 0 ? -1 : 1)} style={{ background:'var(--bg-secondary)', border:'0.5px solid var(--border)', borderRadius: 6, padding:'4px 12px', cursor:'pointer', fontSize: 13, color:'var(--text-primary)' }}>{lbl}</button>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div style={{ display:'flex', gap: 14, flexWrap:'wrap', marginBottom: 14 }}>
        {[['#FCD34D','Order reminder'],['#93C5FD','Shipment en route'],['#6EE7B7','Expected arrival'],['#C4B5FD','At border']].map(([color, label]) => (
          <div key={label} style={{ display:'flex', alignItems:'center', gap: 5, fontSize: 12, color:'var(--text-secondary)' }}>
            <div style={{ width: 10, height: 10, borderRadius: 3, background: color }} />
            {label}
          </div>
        ))}
      </div>

      {/* Grid */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7, 1fr)', border:'0.5px solid var(--border)', borderRadius: 10, overflow:'hidden' }}>
        {DAYS.map(d => (
          <div key={d} style={{ background:'var(--bg-secondary)', padding:'8px 4px', textAlign:'center', fontSize: 12, fontWeight: 500, color:'var(--text-secondary)', borderBottom:'0.5px solid var(--border)' }}>{d}</div>
        ))}
        {cells.map(({ d, other, month: cm, year: cy }, idx) => {
          const isToday = !other && d === today.getDate() && cm === today.getMonth() && cy === today.getFullYear()
          const key = `${cy}-${cm + 1}-${d}`
          const evs = calendarEvents[key] || []
          return (
            <div key={idx} style={{
              minHeight: 88, padding:'6px 8px',
              borderRight: (idx + 1) % 7 === 0 ? 'none' : '0.5px solid var(--border)',
              borderBottom: '0.5px solid var(--border)',
              background: isToday ? 'rgba(59,130,246,0.07)' : other ? 'var(--bg-secondary)' : 'var(--bg-primary)',
              opacity: other ? 0.4 : 1,
            }}>
              <div style={{ fontSize: 13, fontWeight: 500, color: isToday ? '#2563EB' : 'var(--text-secondary)', marginBottom: 4 }}>{d}</div>
              {evs.map((ev, ei) => (
                <div key={ei} style={{ fontSize: 11, padding:'3px 6px', borderRadius: 4, marginBottom: 3, fontWeight: 500, lineHeight: 1.3, ...eventTypeStyle[ev.type] }}>{ev.text}</div>
              ))}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Shipments Tab ─────────────────────────────────────────────────────────────
function ShipmentsTab() {
  const statusStyle = {
    transit: { background:'#DBEAFE', color:'#1D4ED8' },
    border:  { background:'#EDE9FE', color:'#6D28D9' },
    arrived: { background:'#D1FAE5', color:'#065F46' },
    booked:  { background:'#FEF3C7', color:'#92400E' },
  }
  const fillColor = { transit:'#3B82F6', border:'#7C3AED', arrived:'#10B981', booked:'#F59E0B' }
  const statusLabel = { transit:'In transit', border:'At border', arrived:'Arrived', booked:'Booked' }

  const today = new Date()
  const currentMonthIdx = today.getMonth() // 0-based

  return (
    <div style={s.panel}>
      {/* Year timeline header */}
      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 10, color:'var(--text-secondary)' }}>2025 shipment timeline</div>
      <div style={{ display:'flex', height: 28, borderRadius: 8, overflow:'hidden', border:'0.5px solid var(--border)', marginBottom: 20 }}>
        {MONTH_SHORT.map((m, i) => (
          <div key={m} style={{ flex: 1, display:'flex', alignItems:'center', justifyContent:'center', fontSize: 11, fontWeight: 500, color: i === currentMonthIdx ? '#1D4ED8' : 'var(--text-secondary)', background: i === currentMonthIdx ? 'rgba(59,130,246,0.1)' : 'var(--bg-secondary)', borderRight: i < 11 ? '0.5px solid var(--border)' : 'none' }}>{m}</div>
        ))}
      </div>

      {/* Gantt-style bars */}
      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 10, color:'var(--text-secondary)' }}>Active shipment spans</div>
      {shipments.map(sh => (
        <div key={sh.id} style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12, color:'var(--text-secondary)', marginBottom: 4 }}>{sh.name}</div>
          <div style={{ height: 32, borderRadius: 6, background:'var(--bg-secondary)', border:'0.5px solid var(--border)', position:'relative', overflow:'hidden' }}>
            <div style={{ position:'absolute', left:`${sh.barStart}%`, width:`${sh.barWidth}%`, height:'100%', background: fillColor[sh.status], borderRadius: 4, display:'flex', alignItems:'center', paddingLeft: 10, fontSize: 12, fontWeight: 500, color:'#fff' }}>
              {sh.cases} cases
            </div>
          </div>
        </div>
      ))}

      {/* Shipment cards */}
      <div style={{ fontSize: 14, fontWeight: 500, margin:'24px 0 12px' }}>Active shipment details</div>
      {shipments.map(sh => (
        <div key={sh.id} style={{ background:'var(--bg-primary)', border:'0.5px solid var(--border)', borderRadius: 10, padding:'14px 16px', marginBottom: 10 }}>
          <div style={{ display:'flex', alignItems:'center', gap: 10, marginBottom: 8 }}>
            <div style={{ flex: 1, fontSize: 14, fontWeight: 500 }}>{sh.name}</div>
            <div style={{ fontSize: 11, padding:'3px 10px', borderRadius: 20, fontWeight: 500, ...statusStyle[sh.status] }}>{statusLabel[sh.status]}</div>
          </div>
          <div style={{ height: 8, borderRadius: 4, background:'var(--bg-secondary)', border:'0.5px solid var(--border)', overflow:'hidden', marginBottom: 8 }}>
            <div style={{ height:'100%', width:`${sh.progress}%`, borderRadius: 4, background: fillColor[sh.status] }} />
          </div>
          <div style={{ display:'flex', gap: 16, flexWrap:'wrap' }}>
            {[['Origin', sh.origin],['Dest.', sh.destination],['ETA', sh.eta],['Cases', sh.cases]].map(([lbl, val]) => (
              <div key={lbl} style={{ fontSize: 12, color:'var(--text-secondary)' }}><strong style={{ color:'var(--text-primary)', fontWeight: 500 }}>{lbl}</strong> {val}</div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

// ── Purchase Orders Tab ───────────────────────────────────────────────────────
function OrdersTab() {
  const [filter, setFilter] = useState('all')
  const filters = ['all','sent','confirmed','booked','border','delivered']
  const statusLabel = { sent:'Sent', confirmed:'Confirmed', booked:'Booked', border:'At border', delivered:'Delivered' }
  const payLabel    = { paid:'Paid', pending:'Pending', overdue:'Overdue' }

  const statusStyle = {
    sent:      { background:'#F3F4F6', color:'#374151' },
    confirmed: { background:'#FEF3C7', color:'#92400E' },
    booked:    { background:'#DBEAFE', color:'#1D4ED8' },
    border:    { background:'#EDE9FE', color:'#6D28D9' },
    delivered: { background:'#D1FAE5', color:'#065F46' },
  }
  const payStyle = {
    paid:    { background:'#D1FAE5', color:'#065F46' },
    pending: { background:'#FEF3C7', color:'#92400E' },
    overdue: { background:'#FEE2E2', color:'#991B1B' },
  }

  const rows = filter === 'all' ? purchaseOrders : purchaseOrders.filter(p => p.status === filter)
  const total = purchaseOrders.length
  const inTransit = purchaseOrders.filter(p => ['border','booked'].includes(p.status)).length
  const payPending = purchaseOrders.filter(p => p.payment === 'pending' || p.payment === 'overdue').length
  const delivered = purchaseOrders.filter(p => p.status === 'delivered').length

  return (
    <div style={s.panel}>
      {/* Summary cards */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap: 10, marginBottom: 18 }}>
        {[['Total POs', total, 'This year'],['In transit', inTransit, 'Active'],['Pay attention', payPending, '1 overdue'],['Delivered', delivered, 'All confirmed']].map(([label, val, sub], i) => (
          <div key={label} style={{ background:'var(--bg-secondary)', borderRadius: 8, padding:'12px 14px' }}>
            <div style={{ fontSize: 12, color:'var(--text-secondary)', marginBottom: 4 }}>{label}</div>
            <div style={{ fontSize: 22, fontWeight: 500 }}>{val}</div>
            <div style={{ fontSize: 11, color: i === 2 ? '#D97706' : 'var(--text-secondary)', marginTop: 2 }}>{sub}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display:'flex', gap: 8, flexWrap:'wrap', marginBottom: 16 }}>
        {filters.map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ fontSize: 12, padding:'5px 12px', borderRadius: 20, border:'0.5px solid var(--border-hover)', background: filter === f ? 'var(--text-primary)' : 'var(--bg-primary)', color: filter === f ? 'var(--bg-primary)' : 'var(--text-secondary)', cursor:'pointer', fontWeight: 500 }}>
            {f === 'all' ? 'All' : statusLabel[f]}
          </button>
        ))}
      </div>

      {/* Table */}
      <div style={{ border:'0.5px solid var(--border)', borderRadius: 10, overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', tableLayout:'fixed' }}>
          <thead>
            <tr>
              {['PO Number','Supplier','Product','Cases','Order date','Status','Payment'].map((h, i) => (
                <th key={h} style={{ textAlign:'left', fontSize: 12, fontWeight: 500, color:'var(--text-secondary)', padding:'8px 12px', borderBottom:'0.5px solid var(--border)', background:'var(--bg-secondary)', width: i === 0 ? 120 : i === 2 ? 160 : 'auto' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(p => (
              <tr key={p.id} style={{ cursor:'default' }}
                onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-secondary)'}
                onMouseLeave={e => e.currentTarget.style.background = ''}>
                <td style={{ padding:'11px 12px', fontSize: 12, color:'var(--text-secondary)', borderBottom:'0.5px solid var(--border)', fontWeight: 500 }}>{p.id}</td>
                <td style={{ padding:'11px 12px', fontSize: 13, borderBottom:'0.5px solid var(--border)' }}>{p.supplier}</td>
                <td style={{ padding:'11px 12px', fontSize: 13, borderBottom:'0.5px solid var(--border)' }}>{p.product}</td>
                <td style={{ padding:'11px 12px', fontSize: 13, borderBottom:'0.5px solid var(--border)' }}>{p.cases}</td>
                <td style={{ padding:'11px 12px', fontSize: 13, color:'var(--text-secondary)', borderBottom:'0.5px solid var(--border)' }}>{p.date}</td>
                <td style={{ padding:'11px 12px', borderBottom:'0.5px solid var(--border)' }}>
                  <span style={{ fontSize: 11, padding:'3px 10px', borderRadius: 20, fontWeight: 500, ...statusStyle[p.status] }}>{statusLabel[p.status]}</span>
                </td>
                <td style={{ padding:'11px 12px', borderBottom:'0.5px solid var(--border)' }}>
                  <span style={{ fontSize: 11, padding:'3px 10px', borderRadius: 20, fontWeight: 500, ...payStyle[p.payment] }}>{payLabel[p.payment]}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── App Shell ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState('calendar')
  const tabs = [['calendar','Calendar'],['shipments','Shipments'],['orders','Purchase Orders']]

  return (
    <div style={s.app}>
      <div style={s.header}>
        <div style={s.headerTop}>
          <div style={s.logo}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M9 2C5.13 2 2 5.13 2 9s3.13 7 7 7 7-3.13 7-7-3.13-7-7-7zm0 11.5c-2.48 0-4.5-2.02-4.5-4.5S6.52 4.5 9 4.5s4.5 2.02 4.5 4.5-2.02 4.5-4.5 4.5z" fill="#6EE7B7"/>
              <circle cx="9" cy="9" r="2" fill="#6EE7B7"/>
            </svg>
          </div>
          <div>
            <div style={s.title}>Supply Tracker</div>
            <div style={s.subtitle}>Cin7 · MyHillebrand · Live overview</div>
          </div>
        </div>
        <div style={s.tabs}>
          {tabs.map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)} style={s.tab(tab === id)}>{label}</button>
          ))}
        </div>
      </div>

      {tab === 'calendar'  && <CalendarTab />}
      {tab === 'shipments' && <ShipmentsTab />}
      {tab === 'orders'    && <OrdersTab />}
    </div>
  )
}
