// ── Purchase Orders (from Cin7) ──────────────────────────────────────────────
export const purchaseOrders = [
  { id: 'PO-2025-041', supplier: 'Villa Maria',    product: 'Sauvignon Blanc 2024', cases: 240, date: '12 Mar 2025', status: 'border',    payment: 'pending' },
  { id: 'PO-2025-038', supplier: 'Felton Road',    product: 'Pinot Noir 2023',      cases: 180, date: '4 Mar 2025',  status: 'booked',    payment: 'pending' },
  { id: 'PO-2025-035', supplier: 'Millton Estate', product: 'Chardonnay 2024',      cases: 96,  date: '18 Feb 2025', status: 'border',    payment: 'paid'    },
  { id: 'PO-2025-031', supplier: 'Craggy Range',   product: 'Syrah 2023',           cases: 120, date: '2 Feb 2025',  status: 'confirmed', payment: 'pending' },
  { id: 'PO-2025-028', supplier: 'Spy Valley',     product: 'Riesling 2024',        cases: 72,  date: '20 Jan 2025', status: 'sent',      payment: 'pending' },
  { id: 'PO-2025-022', supplier: 'Cloudy Bay',     product: 'Sauvignon Blanc 2023', cases: 300, date: '8 Jan 2025',  status: 'delivered', payment: 'paid'    },
  { id: 'PO-2024-198', supplier: 'Ata Rangi',      product: 'Pinot Noir 2022',      cases: 60,  date: '12 Dec 2024', status: 'delivered', payment: 'paid'    },
  { id: 'PO-2024-195', supplier: 'Dog Point',      product: 'Chardonnay 2023',      cases: 144, date: '1 Dec 2024',  status: 'delivered', payment: 'overdue' },
  { id: 'PO-2024-190', supplier: 'Palliser Estate',product: 'Pinot Gris 2023',      cases: 108, date: '15 Nov 2024', status: 'delivered', payment: 'paid'    },
  { id: 'PO-2024-185', supplier: 'Neudorf',        product: 'Moutere Chardonnay',   cases: 84,  date: '2 Nov 2024',  status: 'delivered', payment: 'paid'    },
];

// ── Shipments (from MyHillebrand weekly export) ───────────────────────────────
export const shipments = [
  {
    id: 'SHP-001',
    poId: 'PO-2025-041',
    name: 'Villa Maria — Sauvignon Blanc 2024',
    origin: 'Auckland, NZ',
    destination: 'Rotterdam, NL',
    status: 'transit',
    progress: 72,
    departDate: '2025-04-07',
    eta: '2025-07-18',
    cases: 240,
    // bar position on the yearly timeline (% from Jan 1)
    barStart: 25,   // ~Apr
    barWidth: 45,   // spans to ~Jul
  },
  {
    id: 'SHP-002',
    poId: 'PO-2025-038',
    name: 'Felton Road — Pinot Noir 2023',
    origin: 'Christchurch, NZ',
    destination: 'Hamburg, DE',
    status: 'transit',
    progress: 38,
    departDate: '2025-06-07',
    eta: '2025-08-02',
    cases: 180,
    barStart: 43,
    barWidth: 30,
  },
  {
    id: 'SHP-003',
    poId: 'PO-2025-035',
    name: 'Millton Estate — Chardonnay 2024',
    origin: 'Gisborne, NZ',
    destination: 'Antwerp, BE',
    status: 'border',
    progress: 90,
    departDate: '2025-04-18',
    eta: '2025-06-24',
    cases: 96,
    barStart: 29,
    barWidth: 21,
  },
  {
    id: 'SHP-004',
    poId: 'PO-2025-031',
    name: 'Craggy Range — Syrah 2023',
    origin: 'Napier, NZ',
    destination: 'London, UK',
    status: 'booked',
    progress: 12,
    departDate: '2025-07-02',
    eta: '2025-09-22',
    cases: 120,
    barStart: 50,
    barWidth: 38,
  },
];

// ── Calendar Events ───────────────────────────────────────────────────────────
export const calendarEvents = {
  '2025-6-3':  [{ type: 'reminder', text: '⏰ Order: Villa Maria SB' }],
  '2025-6-7':  [{ type: 'shipment', text: '🚢 Felton Rd departs' }],
  '2025-6-12': [{ type: 'reminder', text: '⏰ Order: Craggy Range' }],
  '2025-6-18': [{ type: 'border',   text: '🛃 Millton at border' }],
  '2025-6-24': [{ type: 'arrival',  text: '✅ Millton arrives' }],
  '2025-6-28': [{ type: 'reminder', text: '⏰ Order: Spy Valley' }],
  '2025-7-2':  [{ type: 'shipment', text: '🚢 Craggy departs' }],
  '2025-7-18': [{ type: 'arrival',  text: '✅ Villa Maria arrives' }],
  '2025-8-2':  [{ type: 'arrival',  text: '✅ Felton Rd arrives' }],
};
